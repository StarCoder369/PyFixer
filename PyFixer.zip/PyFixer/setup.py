from setuptools import setup, find_packages

setup(
    name="pyfixer",
    version="0.1.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A Python static analyzer and AI-powered code review tool",
    packages=find_packages(),
    install_requires=[
        "pylint",
        "requests",
    ],
    entry_points={
        "console_scripts": [
            "pyfixer=pyfixer.__main__:main",
        ],
    },
    python_requires=">=3.8",
)
