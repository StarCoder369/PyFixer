from pyfixer.scanner import scan_project
import os


def ai_menu():
    while True:
        print("\n--- AI Module ---")
        print("[1] Analyze a Python file")
        print("[2] Ask AI a question")
        print("[3] Back to main menu")
        choice = input("\nEnter your choice: ").strip()

        if choice == "1":
            file_name = input("Enter the path of the Python file to analyze: ").strip()
            if os.path.isfile(file_name) and file_name.endswith(".py"):
                import pyfixer.ai as ai
                ai.analyze_file(file_name)
            else:
                print("Invalid file path. Please enter a valid .py file.")
        elif choice == "2":
            while True:
                print("\n--- Ask AI ---")
                print("[1] Ask about a specific Python file")
                print("[2] Ask a general coding question")
                print("[3] Back to AI menu")
                sub_choice = input("\nEnter your choice: ").strip()

                import pyfixer.ai as ai

                if sub_choice == "1":
                    file_name = input("Enter the path of the Python file: ").strip()
                    if os.path.isfile(file_name) and file_name.endswith(".py"):
                        ai.ask_file(file_name)
                    else:
                        print("Invalid file path. Please enter a valid .py file.")
                elif sub_choice == "2":
                    ai.ask_general()
                elif sub_choice == "3":
                    break
                else:
                    print("Invalid choice.")
        elif choice == "3":
            break
        else:
            print("Invalid choice.")


def main():
    while True:
        print("\n=== PyFixer Main Menu ===")
        print("[1] Static Code Scan (single file)")
        print("[2] AI Module")
        print("[3] Exit")

        choice = input("\nEnter your choice: ").strip()

        if choice == "1":
            file_path = input("Enter the path of the Python file to scan: ").strip()
            if os.path.isfile(file_path) and file_path.endswith(".py"):
                print(f"\n🔍 Running static scan on {file_path}...\n")
                results = scan_project(file_path)
                if results:
                    for file, issues in results.items():
                        print(f"\n📄 {file}")
                        for issue in issues:
                            print("  " + issue)
                else:
                    print("No issues found.")
                print("\n✅ Static scan complete.")
            else:
                print("Invalid file path. Please enter a valid .py file.")

        elif choice == "2":
            ai_menu()

        elif choice == "3":
            print("Goodbye.")
            break

        else:
            print("Invalid choice.")


if __name__ == "__main__":
    main()
