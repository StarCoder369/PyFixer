"""AI-powered code review and Q&A using Ollama (granite-code:3b)."""

import os
import requests

# ---------------- CONFIG ----------------
OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL_NAME = "granite-code:3b"
REQUEST_TIMEOUT = 60  # seconds
MAX_CHARS_PER_REQUEST = 8000
# ----------------------------------------


def collect_file(file_path):
    """Read a single Python file and return its content with a header."""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return f"# {os.path.basename(file_path)}\n" + f.read()
    except OSError as e:
        return f"# {os.path.basename(file_path)}\n# [Could not read file: {e}]"


def query_ollama(prompt):
    """Send a prompt to Ollama and return the response."""
    print("⏳ Sending request to Ollama, please wait...")
    try:
        response = requests.post(
            OLLAMA_URL,
            json={"model": MODEL_NAME, "prompt": prompt, "stream": False},
            timeout=REQUEST_TIMEOUT,
        )
        response.raise_for_status()
        return response.json().get("response", "[No response from model]")
    except requests.RequestException as e:
        return f"[Error contacting Ollama: {e}]"


def analyze_file(file_path):
    """Analyze a single Python file with AI."""
    code = collect_file(file_path)
    prompt = (
        "You are a senior Python developer reviewing this Python file. "
        "Find any possible bugs, logic issues, anti-patterns, or suspicious code. "
        "Explain your findings clearly, and explain how to fix any issues or bugs.\n\n"
        f"{code}"
    )
    response = query_ollama(prompt)
    print("\n🧠 AI Analysis:\n" + response)


def ask_file(file_path):
    """Interactive Q&A about a single Python file."""
    code = collect_file(file_path)

    while True:
        q = input("\n> Ask AI about this file ('exit' to stop): ").strip()
        if q.lower() == "exit":
            break
        prompt = f"{q}\n\nHere's the code:\n{code[:MAX_CHARS_PER_REQUEST]}"
        response = query_ollama(prompt)
        print("\n🤖 AI Response:\n" + response)


def ask_general():
    """Interactive general coding Q&A (no file, just questions)."""
    while True:
        q = input("\n> Ask AI a coding question ('exit' to stop): ").strip()
        if q.lower() == "exit":
            break
        response = query_ollama(q)
        print("\n🤖 AI Response:\n" + response)
