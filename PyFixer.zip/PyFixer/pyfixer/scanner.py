"""Project scanner that runs pylint on Python files."""

import os
import subprocess


def scan_project(path: str = ".") -> dict[str, list[str]]:
    """
    Scan a Python file or all Python files under a directory using pylint.

    Args:
        path (str): File or directory to scan. Defaults to current directory.

    Returns:
        dict[str, list[str]]: Mapping of file paths to lists of pylint issues.
    """
    results = {}

    def run_pylint(file_path: str):
        """Run pylint on a single file and return issues."""
        try:
            result = subprocess.run(
                ["pylint", file_path, "--score=n"],
                capture_output=True,
                text=True,
                check=False,  # pylint exits nonzero if warnings found
                timeout=30,
            )
            lines = [
                line
                for line in result.stdout.strip().splitlines()
                if ":" in line and not line.startswith(("*", "*************"))
            ]
            if lines:
                results[file_path] = lines
        except (subprocess.SubprocessError, OSError) as e:
            results[file_path] = [f"Error running pylint: {e}"]

    # Case 1: path is a single file
    if os.path.isfile(path) and path.endswith(".py"):
        run_pylint(path)

    # Case 2: path is a directory
    elif os.path.isdir(path):
        for root, _, files in os.walk(path):
            for file in files:
                if file.endswith(".py"):
                    run_pylint(os.path.join(root, file))

    else:
        results[path] = ["Invalid path: not a Python file or directory"]

    return results
